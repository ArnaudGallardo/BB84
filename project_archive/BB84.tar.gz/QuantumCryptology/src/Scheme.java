
public interface Scheme {
	int getSize();
	boolean equals(Scheme s);
	public String toString();
}
